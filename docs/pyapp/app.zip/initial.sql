BEGIN TRANSACTION;
CREATE TABLE categories (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    slug        TEXT NOT NULL UNIQUE,
    description TEXT
);
INSERT INTO "categories" VALUES(1,'Веб-сайты','sites','Лендинги, корпоративные сайты и сайты-визитки');
INSERT INTO "categories" VALUES(2,'Интернет-магазины','shops','E-commerce проекты любой сложности');
INSERT INTO "categories" VALUES(3,'UI/UX дизайн','ui-ux','Интерфейсы веб-сервисов и мобильных приложений');
INSERT INTO "categories" VALUES(4,'Брендинг','branding','Логотипы, фирменный стиль, брендбуки');
INSERT INTO "categories" VALUES(5,'Продвижение и поддержка','support','SEO, контекстная реклама, техническая поддержка');
CREATE TABLE comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    user_id    INTEGER REFERENCES users (id) ON DELETE SET NULL,
    text       TEXT    NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "comments" VALUES(1,1,3,'Здравствуйте! Подготовили бриф, ответьте, пожалуйста, на вопросы в документе.','2026-06-23 17:34:00');
INSERT INTO "comments" VALUES(2,1,7,'Бриф заполнил, отправляю вместе с примерами сайтов, которые нравятся.','2026-07-27 13:18:00');
INSERT INTO "comments" VALUES(3,1,3,'Первая версия дизайна готова, ссылка на макет в Figma отправлена на почту.','2026-08-30 16:09:00');
INSERT INTO "comments" VALUES(4,1,7,'Всё отлично, принимаем!','2026-10-03 19:45:00');
INSERT INTO "comments" VALUES(5,2,2,'Здравствуйте! Подготовили бриф, ответьте, пожалуйста, на вопросы в документе.','2026-07-17 17:51:00');
INSERT INTO "comments" VALUES(6,2,5,'Бриф заполнил, отправляю вместе с примерами сайтов, которые нравятся.','2026-08-14 18:56:00');
INSERT INTO "comments" VALUES(7,2,2,'Первая версия дизайна готова, ссылка на макет в Figma отправлена на почту.','2026-09-11 16:25:00');
INSERT INTO "comments" VALUES(8,2,5,'Всё отлично, принимаем!','2026-10-09 17:16:00');
INSERT INTO "comments" VALUES(9,3,4,'Здравствуйте! Подготовили бриф, ответьте, пожалуйста, на вопросы в документе.','2026-08-02 19:06:00');
INSERT INTO "comments" VALUES(10,3,6,'Бриф заполнил, отправляю вместе с примерами сайтов, которые нравятся.','2026-08-26 18:27:00');
INSERT INTO "comments" VALUES(11,3,4,'Первая версия дизайна готова, ссылка на макет в Figma отправлена на почту.','2026-09-19 16:09:00');
INSERT INTO "comments" VALUES(12,3,6,'Всё отлично, принимаем!','2026-10-13 16:56:00');
INSERT INTO "comments" VALUES(13,4,3,'Здравствуйте! Подготовили бриф, ответьте, пожалуйста, на вопросы в документе.','2026-08-22 17:51:00');
INSERT INTO "comments" VALUES(14,4,8,'Бриф заполнил, отправляю вместе с примерами сайтов, которые нравятся.','2026-09-10 19:32:00');
INSERT INTO "comments" VALUES(15,4,3,'Первая версия дизайна готова, ссылка на макет в Figma отправлена на почту.','2026-09-29 16:51:00');
INSERT INTO "comments" VALUES(16,4,8,'Всё отлично, принимаем!','2026-10-18 15:27:00');
INSERT INTO "comments" VALUES(17,5,2,'Добрый день! Прикрепили интерактивный прототип для согласования.','2026-09-14 12:16:00');
INSERT INTO "comments" VALUES(18,5,9,'Прототип посмотрели, всё нравится. Можно переходить к дизайну.','2026-10-02 16:29:00');
INSERT INTO "comments" VALUES(19,5,2,'Итоговые макеты готовы и отправлены вам на проверку, ждём обратной связи.','2026-10-19 17:49:00');
INSERT INTO "comments" VALUES(20,6,3,'Приступили к работе, промежуточный отчёт будет в пятницу.','2026-10-07 13:20:00');
INSERT INTO "comments" VALUES(21,6,5,'Хорошо, ждём.','2026-10-22 16:58:00');
INSERT INTO "comments" VALUES(22,7,2,'Приступили к работе, промежуточный отчёт будет в пятницу.','2026-10-17 16:04:00');
INSERT INTO "comments" VALUES(23,7,7,'Хорошо, ждём.','2026-10-27 19:17:00');
INSERT INTO "comments" VALUES(24,8,4,'Здравствуйте! Подскажите, есть ли у вас готовые фотографии продукции?','2026-10-27 16:58:00');
INSERT INTO "comments" VALUES(25,8,6,'Фото есть, пришлю архив до конца недели.','2026-11-01 09:05:00');
INSERT INTO "comments" VALUES(26,11,5,'Решили отложить проект до следующего года, отменяем заказ.','2026-10-07 10:39:00');
INSERT INTO "comments" VALUES(27,12,3,'Приступили к работе, промежуточный отчёт будет в пятницу.','2026-09-17 19:22:00');
INSERT INTO "comments" VALUES(28,12,7,'Хорошо, ждём.','2026-10-12 11:00:00');
CREATE TABLE feedback (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT    NOT NULL,
    email        TEXT,
    phone        TEXT,
    message      TEXT    NOT NULL,
    is_processed INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "feedback" VALUES(1,'Григорьев Андрей','grigoriev@mail.ru','+7 (917) 111-22-33','Добрый день! Сколько будет стоить сайт для строительной компании примерно на 10 страниц?',0,'2026-11-05 10:24:00');
INSERT INTO "feedback" VALUES(2,'Лебедева Ирина','irina.l@yandex.ru',NULL,'Здравствуйте, интересует редизайн интернет-магазина одежды. Можно созвониться на неделе?',0,'2026-11-04 10:03:00');
INSERT INTO "feedback" VALUES(3,'ООО «Вектор»',NULL,'+7 (495) 123-45-67','Нужен логотип и фирменный стиль для новой IT-компании. Перезвоните, пожалуйста.',1,'2026-10-28 14:41:00');
INSERT INTO "feedback" VALUES(4,'Фёдоров Николай','fedorov.n@gmail.com',NULL,'Работаете ли вы с клиентами из других городов? Нужен сайт для турагентства.',1,'2026-10-22 14:59:00');
CREATE TABLE order_status_history (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    user_id    INTEGER REFERENCES users (id) ON DELETE SET NULL,
    old_status TEXT,
    new_status TEXT    NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "order_status_history" VALUES(1,1,7,NULL,'new','2026-05-20 14:51:00');
INSERT INTO "order_status_history" VALUES(2,1,1,'new','discussion','2026-06-23 15:47:00');
INSERT INTO "order_status_history" VALUES(3,1,1,'discussion','in_progress','2026-07-27 17:40:00');
INSERT INTO "order_status_history" VALUES(4,1,1,'in_progress','review','2026-08-30 10:46:00');
INSERT INTO "order_status_history" VALUES(5,1,7,'review','done','2026-10-03 14:05:00');
INSERT INTO "order_status_history" VALUES(6,2,5,NULL,'new','2026-06-19 16:27:00');
INSERT INTO "order_status_history" VALUES(7,2,1,'new','discussion','2026-07-17 10:25:00');
INSERT INTO "order_status_history" VALUES(8,2,1,'discussion','in_progress','2026-08-14 18:35:00');
INSERT INTO "order_status_history" VALUES(9,2,1,'in_progress','review','2026-09-11 16:55:00');
INSERT INTO "order_status_history" VALUES(10,2,5,'review','done','2026-10-09 10:27:00');
INSERT INTO "order_status_history" VALUES(11,3,6,NULL,'new','2026-07-09 09:36:00');
INSERT INTO "order_status_history" VALUES(12,3,1,'new','discussion','2026-08-02 12:49:00');
INSERT INTO "order_status_history" VALUES(13,3,1,'discussion','in_progress','2026-08-26 11:52:00');
INSERT INTO "order_status_history" VALUES(14,3,1,'in_progress','review','2026-09-19 09:45:00');
INSERT INTO "order_status_history" VALUES(15,3,6,'review','done','2026-10-13 17:56:00');
INSERT INTO "order_status_history" VALUES(16,4,8,NULL,'new','2026-08-03 16:43:00');
INSERT INTO "order_status_history" VALUES(17,4,1,'new','discussion','2026-08-22 16:45:00');
INSERT INTO "order_status_history" VALUES(18,4,1,'discussion','in_progress','2026-09-10 17:16:00');
INSERT INTO "order_status_history" VALUES(19,4,1,'in_progress','review','2026-09-29 17:25:00');
INSERT INTO "order_status_history" VALUES(20,4,8,'review','done','2026-10-18 19:19:00');
INSERT INTO "order_status_history" VALUES(21,5,9,NULL,'new','2026-08-28 11:41:00');
INSERT INTO "order_status_history" VALUES(22,5,1,'new','discussion','2026-09-14 18:29:00');
INSERT INTO "order_status_history" VALUES(23,5,1,'discussion','in_progress','2026-10-01 17:59:00');
INSERT INTO "order_status_history" VALUES(24,5,1,'in_progress','review','2026-10-18 16:23:00');
INSERT INTO "order_status_history" VALUES(25,6,5,NULL,'new','2026-09-22 15:35:00');
INSERT INTO "order_status_history" VALUES(26,6,1,'new','discussion','2026-10-07 19:58:00');
INSERT INTO "order_status_history" VALUES(27,6,1,'discussion','in_progress','2026-10-22 09:53:00');
INSERT INTO "order_status_history" VALUES(28,7,7,NULL,'new','2026-10-07 17:16:00');
INSERT INTO "order_status_history" VALUES(29,7,1,'new','discussion','2026-10-17 16:59:00');
INSERT INTO "order_status_history" VALUES(30,7,1,'discussion','in_progress','2026-10-27 11:27:00');
INSERT INTO "order_status_history" VALUES(31,8,6,NULL,'new','2026-10-23 10:12:00');
INSERT INTO "order_status_history" VALUES(32,8,1,'new','discussion','2026-10-30 15:09:00');
INSERT INTO "order_status_history" VALUES(33,9,8,NULL,'new','2026-11-03 09:28:00');
INSERT INTO "order_status_history" VALUES(34,10,9,NULL,'new','2026-11-05 18:34:00');
INSERT INTO "order_status_history" VALUES(35,11,5,NULL,'new','2026-09-07 10:39:00');
INSERT INTO "order_status_history" VALUES(36,11,5,'new','cancelled','2026-10-07 12:15:00');
INSERT INTO "order_status_history" VALUES(37,12,7,NULL,'new','2026-08-23 09:48:00');
INSERT INTO "order_status_history" VALUES(38,12,1,'new','discussion','2026-09-17 17:17:00');
INSERT INTO "order_status_history" VALUES(39,12,1,'discussion','in_progress','2026-10-12 19:48:00');
CREATE TABLE orders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    service_id  INTEGER REFERENCES services (id) ON DELETE SET NULL,
    designer_id INTEGER REFERENCES users (id) ON DELETE SET NULL,
    title       TEXT    NOT NULL,
    description TEXT    NOT NULL,
    budget      INTEGER CHECK (budget IS NULL OR budget >= 0), -- бюджет, указанный клиентом
    price       INTEGER CHECK (price IS NULL OR price >= 0),   -- согласованная стоимость
    deadline    TEXT,
    status      TEXT    NOT NULL DEFAULT 'new'
                        CHECK (status IN ('new', 'discussion', 'in_progress', 'review', 'done', 'cancelled')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "orders" VALUES(1,7,4,3,'Интернет-магазин «ТехноМаркет»','Нужен интернет-магазин электроники на 3000 товаров с фильтрами, сравнением товаров, онлайн-оплатой и выгрузкой из 1С.',150000,165000,'2026-09-07','done','2026-05-20 14:51:00','2026-10-03 14:05:00');
INSERT INTO "orders" VALUES(2,5,1,2,'Лендинг кофейни «Бодрое утро»','Одностраничный сайт для кофейни: меню, акции, карта, форма бронирования столика.',30000,32000,'2026-08-03','done','2026-06-19 16:27:00','2026-10-09 10:27:00');
INSERT INTO "orders" VALUES(3,6,8,4,'Фирменный стиль эко-фермы «Зелёный луг»','Логотип, фирменные цвета, упаковка для молочной продукции и шаблоны для соцсетей.',50000,48000,'2026-09-27','done','2026-07-09 09:36:00','2026-10-13 17:56:00');
INSERT INTO "orders" VALUES(4,8,2,3,'Сайт стоматологии «Улыбка»','Корпоративный сайт клиники: услуги и цены, врачи, онлайн-запись, отзывы пациентов.',80000,85000,'2026-10-27','done','2026-08-03 16:43:00','2026-10-18 19:19:00');
INSERT INTO "orders" VALUES(5,9,5,2,'Приложение FitLife','Дизайн мобильного приложения для фитнес-клуба: расписание, запись на тренировки, абонементы, прогресс.',90000,95000,'2026-11-18','review','2026-08-28 11:41:00','2026-10-18 16:23:00');
INSERT INTO "orders" VALUES(6,5,9,3,'SEO-продвижение сайта кофейни','Хотим, чтобы сайт кофейни находился по запросам «кофейня рядом», «завтраки в центре».',25000,25000,'2026-11-26','in_progress','2026-09-22 15:35:00','2026-10-22 09:53:00');
INSERT INTO "orders" VALUES(7,7,6,2,'UX-аудит корзины «ТехноМаркет»','Много брошенных корзин, нужно найти проблемы в оформлении заказа.',20000,22000,'2026-11-11','in_progress','2026-10-07 17:16:00','2026-10-27 11:27:00');
INSERT INTO "orders" VALUES(8,6,1,4,'Промо-страница сыров «Зелёный луг»','Лендинг под новую линейку фермерских сыров, нужен к ярмарке.',35000,30000,'2026-12-01','discussion','2026-10-23 10:12:00','2026-10-30 15:09:00');
INSERT INTO "orders" VALUES(9,8,10,NULL,'Поддержка сайта стоматологии','Требуется ежемесячная поддержка сайта: обновления, резервные копии и мелкие правки.',10000,NULL,NULL,'new','2026-11-03 09:28:00','2026-11-03 09:28:00');
INSERT INTO "orders" VALUES(10,9,7,NULL,'Логотип для сети спортзалов','Нужен лаконичный логотип для сети спортзалов «Сила», варианты в тёмной и светлой теме.',15000,NULL,'2026-12-06','new','2026-11-05 18:34:00','2026-11-05 18:34:00');
INSERT INTO "orders" VALUES(11,5,3,NULL,'Редизайн старого сайта пекарни','Сайт пекарни сделан 8 лет назад, нужен современный дизайн. Проект отложили.',40000,NULL,NULL,'cancelled','2026-09-07 10:39:00','2026-10-07 12:15:00');
INSERT INTO "orders" VALUES(12,7,10,3,'Техподдержка «ТехноМаркет»','Обслуживание интернет-магазина после запуска.',10000,12000,'2026-11-03','in_progress','2026-08-23 09:48:00','2026-10-12 19:48:00');
CREATE TABLE payments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    amount     INTEGER NOT NULL CHECK (amount > 0),
    method     TEXT    NOT NULL DEFAULT 'transfer' CHECK (method IN ('card', 'transfer', 'cash')),
    note       TEXT,
    created_by INTEGER REFERENCES users (id) ON DELETE SET NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "payments" VALUES(1,1,82500,'transfer','Предоплата 50 %',1,'2026-05-25 18:19:00');
INSERT INTO "payments" VALUES(2,1,82500,'card','Окончательный расчёт',1,'2026-06-14 14:23:00');
INSERT INTO "payments" VALUES(3,2,16000,'transfer','Предоплата 50 %',1,'2026-06-24 15:36:00');
INSERT INTO "payments" VALUES(4,2,16000,'transfer','Окончательный расчёт',1,'2026-07-14 17:33:00');
INSERT INTO "payments" VALUES(5,3,24000,'transfer','Предоплата 50 %',1,'2026-07-14 12:54:00');
INSERT INTO "payments" VALUES(6,3,24000,'card','Окончательный расчёт',1,'2026-08-03 19:44:00');
INSERT INTO "payments" VALUES(7,4,42500,'transfer','Предоплата 50 %',1,'2026-08-08 12:18:00');
INSERT INTO "payments" VALUES(8,4,42500,'transfer','Окончательный расчёт',1,'2026-08-28 09:02:00');
INSERT INTO "payments" VALUES(9,5,47500,'transfer','Предоплата 50 %',1,'2026-09-02 16:51:00');
INSERT INTO "payments" VALUES(10,6,12500,'transfer','Предоплата 50 %',1,'2026-09-27 10:28:00');
INSERT INTO "payments" VALUES(11,7,11000,'transfer','Предоплата 50 %',1,'2026-10-12 16:23:00');
INSERT INTO "payments" VALUES(12,12,6000,'transfer','Предоплата 50 %',1,'2026-08-28 14:42:00');
INSERT INTO "payments" VALUES(13,12,6000,'card','Оплата поддержки за текущий месяц',1,'2026-11-06 09:37:00');
CREATE TABLE portfolio (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id  INTEGER REFERENCES categories (id) ON DELETE SET NULL,
    title        TEXT    NOT NULL,
    client       TEXT,
    description  TEXT,
    image        TEXT,
    url          TEXT,
    year         INTEGER,
    is_published INTEGER NOT NULL DEFAULT 1,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "portfolio" VALUES(1,1,'Кофейня «Бодрое утро»','Кофейня «Бодрое утро»','Промо-сайт кофейни с меню и онлайн-бронированием. Лендинг для городской кофейни: меню с фотографиями, акции, бронирование столиков и карта проезда. После запуска количество бронирований через сайт выросло в 2,5 раза.','portfolio-1.svg',NULL,2026,1,'2026-01-30 18:49:00');
INSERT INTO "portfolio" VALUES(2,2,'ТехноМаркет','ООО «ТехноМаркет»','Интернет-магазин электроники на 3000 товаров. Интернет-магазин с умными фильтрами, сравнением товаров, онлайн-оплатой и синхронизацией с 1С. Конверсия выросла на 38 % по сравнению со старым сайтом.','portfolio-2.svg',NULL,2026,1,'2026-02-19 16:44:00');
INSERT INTO "portfolio" VALUES(3,4,'Зелёный луг','Эко-ферма «Зелёный луг»','Фирменный стиль и упаковка. Айдентика для фермерского хозяйства: логотип, палитра, упаковка молочной продукции, шаблоны для соцсетей.','portfolio-3.svg',NULL,2026,1,'2026-03-11 11:34:00');
INSERT INTO "portfolio" VALUES(4,3,'FitLife','Сеть фитнес-клубов','Мобильное приложение для фитнес-клуба. Приложение для записи на тренировки, покупки абонементов и отслеживания прогресса. Средняя оценка в магазинах приложений — 4,8.','portfolio-4.svg',NULL,2026,1,'2026-03-31 12:30:00');
INSERT INTO "portfolio" VALUES(5,1,'Стоматология «Улыбка»','Клиника «Улыбка»','Корпоративный сайт клиники с онлайн-записью. Сайт клиники с каталогом услуг и цен, страницами врачей и онлайн-записью на приём.','portfolio-5.svg',NULL,2025,1,'2026-04-20 18:08:00');
INSERT INTO "portfolio" VALUES(6,3,'Финтех-дашборд','FinPoint','Интерфейс личного кабинета для финансового сервиса. Дашборд для управления финансами малого бизнеса: платежи, аналитика, отчёты для бухгалтерии.','portfolio-6.svg',NULL,2025,1,'2026-05-10 18:56:00');
INSERT INTO "portfolio" VALUES(7,2,'Книжная лавка','Книжная лавка «Переплёт»','Интернет-магазин независимого книжного. Магазин с подборками, отзывами читателей, подарочными сертификатами и самовывозом.','portfolio-7.svg',NULL,2025,1,'2026-05-30 17:18:00');
INSERT INTO "portfolio" VALUES(8,1,'Автосервис «МоторДом»','Автосервис «МоторДом»','Сайт автосервиса с калькулятором ТО. Сайт с онлайн-калькулятором стоимости техобслуживания и записью на сервис. Продвигается в топ-3 по городу.','portfolio-8.svg',NULL,2025,1,'2026-06-19 10:26:00');
INSERT INTO "portfolio" VALUES(9,4,'Сила','Сеть спортзалов «Сила»','Логотип и айдентика сети спортзалов. Энергичный фирменный стиль для сети спортзалов: логотип, навигация в залах, мерч.','portfolio-9.svg',NULL,2024,1,'2026-07-09 19:10:00');
CREATE TABLE reviews (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    order_id    INTEGER UNIQUE REFERENCES orders (id) ON DELETE SET NULL,
    rating      INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    text        TEXT    NOT NULL,
    is_approved INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "reviews" VALUES(1,7,1,5,'Магазин запустили точно в срок. Отдельное спасибо за интеграцию с 1С — сэкономили кучу времени на обновлении остатков. Продажи с сайта выросли почти на 40 %.',1,'2026-10-24 18:19:00');
INSERT INTO "reviews" VALUES(2,5,2,5,'Очень довольны лендингом: красиво, быстро, удобно бронировать столики с телефона. Гости часто хвалят сайт.',1,'2026-09-30 15:24:00');
INSERT INTO "reviews" VALUES(3,6,3,5,'Мария тонко почувствовала, чего мы хотим. Упаковка выделяется на полке, покупатели узнают нас издалека.',1,'2026-10-23 17:51:00');
INSERT INTO "reviews" VALUES(4,8,4,4,'Хороший сайт, пациенты записываются онлайн. Было немного задержек с правками, но результат того стоил.',0,'2026-10-20 15:00:00');
CREATE TABLE services (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id       INTEGER NOT NULL REFERENCES categories (id) ON DELETE RESTRICT,
    title             TEXT    NOT NULL,
    short_description TEXT,
    description       TEXT,
    price_from        INTEGER NOT NULL CHECK (price_from >= 0),
    duration_days     INTEGER NOT NULL DEFAULT 14 CHECK (duration_days > 0),
    is_active         INTEGER NOT NULL DEFAULT 1,
    created_at        TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "services" VALUES(1,1,'Лендинг','Одностраничный продающий сайт под рекламную кампанию','Проектируем структуру, пишем продающие тексты, разрабатываем уникальный дизайн и адаптивную вёрстку.

В стоимость входит: прототип, дизайн-макет для ПК и смартфонов, вёрстка, подключение формы заявок и систем аналитики, публикация на хостинге.',25000,10,1,'2026-04-20 10:20:00');
INSERT INTO "services" VALUES(2,1,'Корпоративный сайт','Многостраничный сайт компании с системой управления','Сайт компании до 15 страниц: о компании, услуги, проекты, новости, контакты.

Разрабатываем фирменный дизайн, подключаем систему управления содержимым, обучаем сотрудников клиента работе с сайтом.',70000,30,1,'2026-04-20 17:32:00');
INSERT INTO "services" VALUES(3,1,'Редизайн сайта','Обновление дизайна и юзабилити существующего сайта','Анализируем текущий сайт и поведение посетителей, выявляем слабые места и создаём новый дизайн с сохранением наработанных позиций в поисковых системах.',40000,21,1,'2026-04-20 19:55:00');
INSERT INTO "services" VALUES(4,2,'Интернет-магазин','Магазин с каталогом, корзиной и онлайн-оплатой','Каталог с фильтрами, карточки товаров, корзина, личный кабинет покупателя, подключение онлайн-оплаты и служб доставки, интеграция с 1С.',120000,45,1,'2026-04-20 10:56:00');
INSERT INTO "services" VALUES(5,3,'Дизайн мобильного приложения','UX-исследование и дизайн интерфейсов iOS и Android','Проводим интервью с пользователями, строим пользовательские сценарии, создаём интерактивный прототип и итоговый дизайн с UI-китом для разработчиков.',80000,30,1,'2026-04-20 12:57:00');
INSERT INTO "services" VALUES(6,3,'UX-аудит','Экспертная оценка удобства сайта или приложения','Проверяем интерфейс по 100+ критериям юзабилити, анализируем данные веб-аналитики и записи сессий. Результат — отчёт с приоритизированным списком рекомендаций.',20000,7,1,'2026-04-20 18:39:00');
INSERT INTO "services" VALUES(7,4,'Логотип','Разработка логотипа в трёх вариантах','Изучаем бизнес и конкурентов, предлагаем 3 концепции логотипа, дорабатываем выбранную. Передаём исходники во всех необходимых форматах.',15000,7,1,'2026-04-20 17:26:00');
INSERT INTO "services" VALUES(8,4,'Фирменный стиль','Логотип, цвета, шрифты, носители и брендбук','Полный комплекс айдентики: логотип, палитра, типографика, визитки, бланки, шаблоны для соцсетей и брендбук с правилами использования.',45000,20,1,'2026-04-20 18:35:00');
INSERT INTO "services" VALUES(9,5,'SEO-продвижение','Вывод сайта в топ поисковых систем','Техническая оптимизация, сбор семантического ядра, оптимизация контента, ежемесячная отчётность о позициях и трафике.',25000,30,1,'2026-04-20 16:48:00');
INSERT INTO "services" VALUES(10,5,'Техническая поддержка','Обновления, резервное копирование и доработки сайта','Ежемесячное обслуживание сайта: обновление ПО, резервные копии, мониторинг доступности, до 5 часов мелких доработок в месяц.',10000,30,1,'2026-04-20 18:28:00');
CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    phone         TEXT,
    password_hash TEXT    NOT NULL,
    role          TEXT    NOT NULL DEFAULT 'client'
                          CHECK (role IN ('client', 'designer', 'admin')),
    position      TEXT,                       -- должность (для сотрудников)
    bio           TEXT,                       -- краткая информация о сотруднике
    is_active     INTEGER NOT NULL DEFAULT 1, -- 0 — учётная запись заблокирована
    created_at    TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "users" VALUES(1,'Петров Иван','admin@webcraft.ru','+7 (900) 100-00-01','scrypt:32768:8:1$Dz8lcCvoJ7vxPp8a$673b6e504aaec6a459fb14f1f86667d37a7481cd049a2085f893c3e9001aff0fa6493efdf93d1e7f2e8bb41e53b9dac576f95daaf5f62c4b1dfa22baae1fcae8','admin','Руководитель студии','Основатель студии, 12 лет в веб-разработке. Отвечает за стратегию и работу с ключевыми клиентами.',1,'2025-10-02 12:00:00');
INSERT INTO "users" VALUES(2,'Смирнова Анна','anna@webcraft.ru','+7 (900) 100-00-02','scrypt:32768:8:1$UcCTweJ7a6DLz2xd$1334e01af7c5009b3a4fb976c2f1ef50abb2567cc34ed292ac97d0912423a6a7ea276032f895eb53e4f664d9dcaf1092235943d06fa2c684425cbc4f4f06e774','designer','Ведущий UI/UX-дизайнер','Проектирует интерфейсы веб-сервисов и мобильных приложений, проводит UX-исследования.',1,'2025-10-12 18:05:00');
INSERT INTO "users" VALUES(3,'Козлов Дмитрий','dmitry@webcraft.ru','+7 (900) 100-00-03','scrypt:32768:8:1$Xxq2yBU5mCMr5pVz$86e9bb2eb140ecd9813f313502b5ea3716c40b7c7b2030f7522bfc02210b80ef8c5bb192b1be1c34a5be5b9bdef2d35771f4c321688bba3dbc16f7e3390aa5d8','designer','Веб-дизайнер, верстальщик','Создаёт корпоративные сайты и интернет-магазины, отвечает за адаптивную вёрстку.',1,'2025-10-22 10:18:00');
INSERT INTO "users" VALUES(4,'Волкова Мария','maria@webcraft.ru','+7 (900) 100-00-04','scrypt:32768:8:1$g9KwAzqvU9gU8vZe$37e0268fd51205b966794afb640cf49a8d499bfbec26491b69b9285108ed2f24522fbbfd64e2f71a5c4002d1090b846cc9aa3124ee2b3f9ce1c750415f6449d9','designer','Графический дизайнер','Специализируется на брендинге: логотипы, фирменный стиль, полиграфия.',1,'2025-11-01 10:28:00');
INSERT INTO "users" VALUES(5,'Иванов Сергей','client@mail.ru','+7 (912) 345-67-89','scrypt:32768:8:1$ogsuZJ9x2nd2rSjI$e2541a10fcd502080e7959d7618c70a7b0590fa7f2406578c8bb4ef5a6f57b52598d811eee7151d469768edfc15618a61f4e2026092cfa92afcb782408060740','client',NULL,NULL,1,'2026-06-11 09:52:00');
INSERT INTO "users" VALUES(6,'Кузнецова Ольга','olga.k@mail.ru','+7 (913) 222-33-44','scrypt:32768:8:1$ejdmxjjpPORt3ipZ$0fd594ee3e2c1b37c83c1eee52f1809c26045a0c4b6ab4d09190c3ed4206a515eb74c83e99bce8118195cff7f09d6dcd7263a1d80f655c73379bc3f1860e5d2e','client',NULL,NULL,1,'2026-06-19 19:31:00');
INSERT INTO "users" VALUES(7,'Морозов Алексей','morozov@technomarket.ru','+7 (914) 555-66-77','scrypt:32768:8:1$AWZ5Wimwm5OnBwnl$8c7a2d5613543e62ac29f753ba5b2964846227cf287eb95af981b7138b60a616eb4ee43651879f8ce30bbbf812c68555478fa6797bbeb2494f92b6a0851486fc','client',NULL,NULL,1,'2026-06-27 19:20:00');
INSERT INTO "users" VALUES(8,'Новикова Екатерина','ekaterina.n@yandex.ru','+7 (915) 888-99-00','scrypt:32768:8:1$MnD2v1KcXPDAFcun$7f10f81b1b73706c2fc4a6f4abec0ff0676988c3693fd35289c5e5361621c517eee1ceae227a2d8e0e604f31c10ecfda203257241d13baa2352da6d952866a2f','client',NULL,NULL,1,'2026-07-05 12:25:00');
INSERT INTO "users" VALUES(9,'Соколов Павел','p.sokolov@gmail.com','+7 (916) 123-45-67','scrypt:32768:8:1$mewTf1UZctJVI1a2$8484a2b9791a75ddd87f78f1c93238cea80ed14852113d9b74c1af477a8d49332f4a868b81f7d22e90ee6703971e7a9a25fd79614394e8cb7a57a09347bada72','client',NULL,NULL,1,'2026-07-13 13:22:00');
CREATE INDEX idx_orders_client    ON orders (client_id);
CREATE INDEX idx_orders_designer  ON orders (designer_id);
CREATE INDEX idx_orders_status    ON orders (status);
CREATE INDEX idx_services_cat     ON services (category_id);
CREATE INDEX idx_portfolio_cat    ON portfolio (category_id);
CREATE INDEX idx_comments_order   ON comments (order_id);
CREATE INDEX idx_payments_order   ON payments (order_id);
CREATE INDEX idx_history_order    ON order_status_history (order_id);
CREATE TRIGGER trg_orders_updated_at
AFTER UPDATE ON orders
FOR EACH ROW
WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE orders SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
END;
CREATE VIEW order_summary AS
SELECT o.*,
       c.name  AS client_name,
       c.email AS client_email,
       c.phone AS client_phone,
       d.name  AS designer_name,
       s.title AS service_title,
       IFNULL((SELECT SUM(p.amount) FROM payments p WHERE p.order_id = o.id), 0) AS paid
FROM orders o
JOIN users c         ON c.id = o.client_id
LEFT JOIN users d    ON d.id = o.designer_id
LEFT JOIN services s ON s.id = o.service_id;
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('categories',5);
INSERT INTO "sqlite_sequence" VALUES('services',10);
INSERT INTO "sqlite_sequence" VALUES('users',9);
INSERT INTO "sqlite_sequence" VALUES('orders',12);
INSERT INTO "sqlite_sequence" VALUES('order_status_history',39);
INSERT INTO "sqlite_sequence" VALUES('comments',28);
INSERT INTO "sqlite_sequence" VALUES('payments',13);
INSERT INTO "sqlite_sequence" VALUES('portfolio',9);
INSERT INTO "sqlite_sequence" VALUES('reviews',4);
INSERT INTO "sqlite_sequence" VALUES('feedback',4);
COMMIT;