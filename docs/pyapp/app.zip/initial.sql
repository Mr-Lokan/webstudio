BEGIN TRANSACTION;
CREATE TABLE categories (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    slug        TEXT NOT NULL UNIQUE,
    description TEXT
);
INSERT INTO "categories" VALUES(1,'Веб-сайты','sites','Лендинги, корпоративные сайты и сайты-визитки');
INSERT INTO "categories" VALUES(2,'Интернет-магазины','shops','E-commerce проекты любой сложности');
INSERT INTO "categories" VALUES(3,'UI/UX дизайн','ui-ux','Интерфейсы веб-сервисов и мобильных приложений');
INSERT INTO "categories" VALUES(4,'Брендинг','branding','Логотипы, фирменный стиль, брендбуки');
INSERT INTO "categories" VALUES(5,'Продвижение и поддержка','support','SEO, контекстная реклама, техническая поддержка');
CREATE TABLE comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    user_id    INTEGER REFERENCES users (id) ON DELETE SET NULL,
    text       TEXT    NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE TABLE feedback (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT    NOT NULL,
    email        TEXT,
    phone        TEXT,
    message      TEXT    NOT NULL,
    is_processed INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "feedback" VALUES(3,'ООО «Вектор»',NULL,'+7 (495) 123-45-67','Нужен логотип и фирменный стиль для новой IT-компании. Перезвоните, пожалуйста.',1,'2026-10-23 14:41:00');
INSERT INTO "feedback" VALUES(4,'Фёдоров Николай','fedorov.n@gmail.com',NULL,'Работаете ли вы с клиентами из других городов? Нужен сайт для турагентства.',1,'2026-10-17 14:59:00');
CREATE TABLE order_status_history (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    user_id    INTEGER REFERENCES users (id) ON DELETE SET NULL,
    old_status TEXT,
    new_status TEXT    NOT NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE TABLE orders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    service_id  INTEGER REFERENCES services (id) ON DELETE SET NULL,
    designer_id INTEGER REFERENCES users (id) ON DELETE SET NULL,
    title       TEXT    NOT NULL,
    description TEXT    NOT NULL,
    budget      INTEGER CHECK (budget IS NULL OR budget >= 0), -- бюджет, указанный клиентом
    price       INTEGER CHECK (price IS NULL OR price >= 0),   -- согласованная стоимость
    deadline    TEXT,
    status      TEXT    NOT NULL DEFAULT 'new'
                        CHECK (status IN ('new', 'discussion', 'in_progress', 'review', 'done', 'cancelled')),
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE TABLE payments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id   INTEGER NOT NULL REFERENCES orders (id) ON DELETE CASCADE,
    amount     INTEGER NOT NULL CHECK (amount > 0),
    method     TEXT    NOT NULL DEFAULT 'transfer' CHECK (method IN ('card', 'transfer', 'cash')),
    note       TEXT,
    created_by INTEGER REFERENCES users (id) ON DELETE SET NULL,
    created_at TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
CREATE TABLE portfolio (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id  INTEGER REFERENCES categories (id) ON DELETE SET NULL,
    title        TEXT    NOT NULL,
    client       TEXT,
    description  TEXT,
    image        TEXT,
    url          TEXT,
    year         INTEGER,
    is_published INTEGER NOT NULL DEFAULT 1,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "portfolio" VALUES(1,1,'Кофейня «Бодрое утро»','Кофейня «Бодрое утро»','Промо-сайт кофейни с меню и онлайн-бронированием. Лендинг для городской кофейни: меню с фотографиями, акции, бронирование столиков и карта проезда. После запуска количество бронирований через сайт выросло в 2,5 раза.','portfolio-1.svg',NULL,2026,1,'2026-01-25 18:49:00');
INSERT INTO "portfolio" VALUES(2,2,'ТехноМаркет','ООО «ТехноМаркет»','Интернет-магазин электроники на 3000 товаров. Интернет-магазин с умными фильтрами, сравнением товаров, онлайн-оплатой и синхронизацией с 1С. Конверсия выросла на 38 % по сравнению со старым сайтом.','portfolio-2.svg',NULL,2026,1,'2026-02-14 16:44:00');
INSERT INTO "portfolio" VALUES(3,4,'Зелёный луг','Эко-ферма «Зелёный луг»','Фирменный стиль и упаковка. Айдентика для фермерского хозяйства: логотип, палитра, упаковка молочной продукции, шаблоны для соцсетей.','portfolio-3.svg',NULL,2026,1,'2026-03-06 11:34:00');
INSERT INTO "portfolio" VALUES(4,3,'FitLife','Сеть фитнес-клубов','Мобильное приложение для фитнес-клуба. Приложение для записи на тренировки, покупки абонементов и отслеживания прогресса. Средняя оценка в магазинах приложений — 4,8.','portfolio-4.svg',NULL,2026,1,'2026-03-26 12:30:00');
INSERT INTO "portfolio" VALUES(5,1,'Стоматология «Улыбка»','Клиника «Улыбка»','Корпоративный сайт клиники с онлайн-записью. Сайт клиники с каталогом услуг и цен, страницами врачей и онлайн-записью на приём.','portfolio-5.svg',NULL,2025,1,'2026-04-15 18:08:00');
INSERT INTO "portfolio" VALUES(6,3,'Финтех-дашборд','FinPoint','Интерфейс личного кабинета для финансового сервиса. Дашборд для управления финансами малого бизнеса: платежи, аналитика, отчёты для бухгалтерии.','portfolio-6.svg',NULL,2025,1,'2026-05-05 18:56:00');
INSERT INTO "portfolio" VALUES(7,2,'Книжная лавка','Книжная лавка «Переплёт»','Интернет-магазин независимого книжного. Магазин с подборками, отзывами читателей, подарочными сертификатами и самовывозом.','portfolio-7.svg',NULL,2025,1,'2026-05-25 17:18:00');
INSERT INTO "portfolio" VALUES(8,1,'Автосервис «МоторДом»','Автосервис «МоторДом»','Сайт автосервиса с калькулятором ТО. Сайт с онлайн-калькулятором стоимости техобслуживания и записью на сервис. Продвигается в топ-3 по городу.','portfolio-8.svg',NULL,2025,1,'2026-06-14 10:26:00');
INSERT INTO "portfolio" VALUES(9,4,'Сила','Сеть спортзалов «Сила»','Логотип и айдентика сети спортзалов. Энергичный фирменный стиль для сети спортзалов: логотип, навигация в залах, мерч.','portfolio-9.svg',NULL,2024,1,'2026-07-04 19:10:00');
CREATE TABLE reviews (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    order_id    INTEGER UNIQUE REFERENCES orders (id) ON DELETE SET NULL,
    rating      INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    text        TEXT    NOT NULL,
    is_approved INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "reviews" VALUES(1,7,NULL,5,'Магазин запустили точно в срок. Отдельное спасибо за интеграцию с 1С — сэкономили кучу времени на обновлении остатков. Продажи с сайта выросли почти на 40 %.',1,'2026-10-19 18:19:00');
INSERT INTO "reviews" VALUES(2,5,NULL,5,'Очень довольны лендингом: красиво, быстро, удобно бронировать столики с телефона. Гости часто хвалят сайт.',1,'2026-09-25 15:24:00');
INSERT INTO "reviews" VALUES(3,6,NULL,5,'Мария тонко почувствовала, чего мы хотим. Упаковка выделяется на полке, покупатели узнают нас издалека.',1,'2026-10-18 17:51:00');
INSERT INTO "reviews" VALUES(4,8,NULL,4,'Хороший сайт, пациенты записываются онлайн. Было немного задержек с правками, но результат того стоил.',1,'2026-10-15 15:00:00');
CREATE TABLE services (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id       INTEGER NOT NULL REFERENCES categories (id) ON DELETE RESTRICT,
    title             TEXT    NOT NULL,
    short_description TEXT,
    description       TEXT,
    price_from        INTEGER NOT NULL CHECK (price_from >= 0),
    duration_days     INTEGER NOT NULL DEFAULT 14 CHECK (duration_days > 0),
    is_active         INTEGER NOT NULL DEFAULT 1,
    created_at        TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "services" VALUES(1,1,'Лендинг','Одностраничный продающий сайт под рекламную кампанию','Проектируем структуру, пишем продающие тексты, разрабатываем уникальный дизайн и адаптивную вёрстку.

В стоимость входит: прототип, дизайн-макет для ПК и смартфонов, вёрстка, подключение формы заявок и систем аналитики, публикация на хостинге.',25000,10,1,'2026-04-15 10:20:00');
INSERT INTO "services" VALUES(2,1,'Корпоративный сайт','Многостраничный сайт компании с системой управления','Сайт компании до 15 страниц: о компании, услуги, проекты, новости, контакты.

Разрабатываем фирменный дизайн, подключаем систему управления содержимым, обучаем сотрудников клиента работе с сайтом.',70000,30,1,'2026-04-15 17:32:00');
INSERT INTO "services" VALUES(3,1,'Редизайн сайта','Обновление дизайна и юзабилити существующего сайта','Анализируем текущий сайт и поведение посетителей, выявляем слабые места и создаём новый дизайн с сохранением наработанных позиций в поисковых системах.',40000,21,1,'2026-04-15 19:55:00');
INSERT INTO "services" VALUES(4,2,'Интернет-магазин','Магазин с каталогом, корзиной и онлайн-оплатой','Каталог с фильтрами, карточки товаров, корзина, личный кабинет покупателя, подключение онлайн-оплаты и служб доставки, интеграция с 1С.',120000,45,1,'2026-04-15 10:56:00');
INSERT INTO "services" VALUES(5,3,'Дизайн мобильного приложения','UX-исследование и дизайн интерфейсов iOS и Android','Проводим интервью с пользователями, строим пользовательские сценарии, создаём интерактивный прототип и итоговый дизайн с UI-китом для разработчиков.',80000,30,1,'2026-04-15 12:57:00');
INSERT INTO "services" VALUES(6,3,'UX-аудит','Экспертная оценка удобства сайта или приложения','Проверяем интерфейс по 100+ критериям юзабилити, анализируем данные веб-аналитики и записи сессий. Результат — отчёт с приоритизированным списком рекомендаций.',20000,7,1,'2026-04-15 18:39:00');
INSERT INTO "services" VALUES(7,4,'Логотип','Разработка логотипа в трёх вариантах','Изучаем бизнес и конкурентов, предлагаем 3 концепции логотипа, дорабатываем выбранную. Передаём исходники во всех необходимых форматах.',15000,7,1,'2026-04-15 17:26:00');
INSERT INTO "services" VALUES(8,4,'Фирменный стиль','Логотип, цвета, шрифты, носители и брендбук','Полный комплекс айдентики: логотип, палитра, типографика, визитки, бланки, шаблоны для соцсетей и брендбук с правилами использования.',45000,20,1,'2026-04-15 18:35:00');
INSERT INTO "services" VALUES(9,5,'SEO-продвижение','Вывод сайта в топ поисковых систем','Техническая оптимизация, сбор семантического ядра, оптимизация контента, ежемесячная отчётность о позициях и трафике.',25000,30,1,'2026-04-15 16:48:00');
INSERT INTO "services" VALUES(10,5,'Техническая поддержка','Обновления, резервное копирование и доработки сайта','Ежемесячное обслуживание сайта: обновление ПО, резервные копии, мониторинг доступности, до 5 часов мелких доработок в месяц.',10000,30,1,'2026-04-15 18:28:00');
CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL,
    email         TEXT    NOT NULL UNIQUE,
    phone         TEXT,
    password_hash TEXT    NOT NULL,
    role          TEXT    NOT NULL DEFAULT 'client'
                          CHECK (role IN ('client', 'designer', 'admin')),
    position      TEXT,                       -- должность (для сотрудников)
    bio           TEXT,                       -- краткая информация о сотруднике
    is_active     INTEGER NOT NULL DEFAULT 1, -- 0 — учётная запись заблокирована
    created_at    TEXT    NOT NULL DEFAULT (datetime('now', 'localtime'))
);
INSERT INTO "users" VALUES(1,'Петров Иван','admin@webcraft.ru','+7 (900) 100-00-01','scrypt:32768:8:1$KkzaxUM2B1GtvhPV$1660244790509568ef0422b7b6f48878e8b5bac0467160ca04864cb15e872491cdf82737492c32b711fba75ffb2418e45a885fe35ab824fed3e1f8d51843f626','admin','Руководитель студии','Основатель студии, 12 лет в веб-разработке. Отвечает за стратегию и работу с ключевыми клиентами.',1,'2025-09-27 12:00:00');
INSERT INTO "users" VALUES(2,'Смирнова Анна','anna@webcraft.ru','+7 (900) 100-00-02','scrypt:32768:8:1$epHdhTJlrbxEQ4F3$b46d12dabfe6547e301d910cff652453fd1a7edeb13c055172261e1e05148a30e5867e2c0a5d3b13de3976fc2edcd89fb9ae78711d83c512e7f12094f7a45dd9','designer','Ведущий UI/UX-дизайнер','Проектирует интерфейсы веб-сервисов и мобильных приложений, проводит UX-исследования.',1,'2025-10-07 18:05:00');
INSERT INTO "users" VALUES(3,'Козлов Дмитрий','dmitry@webcraft.ru','+7 (900) 100-00-03','scrypt:32768:8:1$w45h85FDZkEFj1HJ$17a50a48e6a044c83e4c0ccd3a23669bf21a1040dbf9463df89996efdc828de54ef8304d677a103561d7584a070bce47f3846c72039bd587e0753bc15eb9a443','designer','Веб-дизайнер, верстальщик','Создаёт корпоративные сайты и интернет-магазины, отвечает за адаптивную вёрстку.',1,'2025-10-17 10:18:00');
INSERT INTO "users" VALUES(4,'Волкова Мария','maria@webcraft.ru','+7 (900) 100-00-04','scrypt:32768:8:1$50xnjO2CmvooxHI4$06cc56a6373bbecf22615bdec97cd827e7d0e2867fc69d23b2ee39155b8bb775e418d74e19fc5c7d1bbcfa42ccc513cbb2cb6f05f032c5916ab8dd3d683d458b','designer','Графический дизайнер','Специализируется на брендинге: логотипы, фирменный стиль, полиграфия.',1,'2025-10-27 10:28:00');
INSERT INTO "users" VALUES(5,'Иванов Сергей','client@mail.ru','+7 (912) 345-67-89','scrypt:32768:8:1$YI9RxL2R9NCu5Dky$8a9a6d57bcdd9ab68f96c9661f28d178454eb4b7a560bae529e32026b078c9a9316c807e8b1ea3dbebbffd04fe2b5b905097d5d7341b949705bffeed94212d7f','client',NULL,NULL,1,'2026-06-06 09:52:00');
INSERT INTO "users" VALUES(6,'Кузнецова Ольга','olga.k@mail.ru','+7 (913) 222-33-44','scrypt:32768:8:1$hJJcwxDoXR6Uiuht$34c92144d164e7df555042a383887cdc1fb8fec0d19f21392c64f460a3fddddb696c3737e032fed10e44d6cc941ef79cf30386f9c796c5c19051690054a3e3ec','client',NULL,NULL,1,'2026-06-14 19:31:00');
INSERT INTO "users" VALUES(7,'Морозов Алексей','morozov@technomarket.ru','+7 (914) 555-66-77','scrypt:32768:8:1$9U5GiaUCaPODpvsa$b72a9d63df649c51518145d4de5a408a18921a065a3fa9000f975a735c3cad991e6ea5c35222a18b59460a568cb0b2949eaf2ba825583cdaa1b8fd6e48fa1705','client',NULL,NULL,1,'2026-06-22 19:20:00');
INSERT INTO "users" VALUES(8,'Новикова Екатерина','ekaterina.n@yandex.ru','+7 (915) 888-99-00','scrypt:32768:8:1$7VwqXpX4Y0O1gxdA$c5d9eb04efaab57a31f86fe9e2c2b11555a0ab500db4bf1218276c54c17fe66ef2ec8f33c0eba6015395f6d7fde36e11225c44556b59f948f4bc2db80c5286c3','client',NULL,NULL,1,'2026-06-30 12:25:00');
INSERT INTO "users" VALUES(9,'Соколов Павел','p.sokolov@gmail.com','+7 (916) 123-45-67','scrypt:32768:8:1$Pl19tkzKlpRqrAAY$58701c7deed3449822ff69d920011ecccc06970657c6cc4f7a69f7ae335aea28667f09fb59141e39729fc846a6dacd54008941e64c34cf7af1c51e0881934456','client',NULL,NULL,1,'2026-07-08 13:22:00');
CREATE INDEX idx_orders_client    ON orders (client_id);
CREATE INDEX idx_orders_designer  ON orders (designer_id);
CREATE INDEX idx_orders_status    ON orders (status);
CREATE INDEX idx_services_cat     ON services (category_id);
CREATE INDEX idx_portfolio_cat    ON portfolio (category_id);
CREATE INDEX idx_comments_order   ON comments (order_id);
CREATE INDEX idx_payments_order   ON payments (order_id);
CREATE INDEX idx_history_order    ON order_status_history (order_id);
CREATE TRIGGER trg_orders_updated_at
AFTER UPDATE ON orders
FOR EACH ROW
WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE orders SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
END;
CREATE VIEW order_summary AS
SELECT o.*,
       c.name  AS client_name,
       c.email AS client_email,
       c.phone AS client_phone,
       d.name  AS designer_name,
       s.title AS service_title,
       IFNULL((SELECT SUM(p.amount) FROM payments p WHERE p.order_id = o.id), 0) AS paid
FROM orders o
JOIN users c         ON c.id = o.client_id
LEFT JOIN users d    ON d.id = o.designer_id
LEFT JOIN services s ON s.id = o.service_id;
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('categories',5);
INSERT INTO "sqlite_sequence" VALUES('services',10);
INSERT INTO "sqlite_sequence" VALUES('users',9);
INSERT INTO "sqlite_sequence" VALUES('orders',13);
INSERT INTO "sqlite_sequence" VALUES('order_status_history',41);
INSERT INTO "sqlite_sequence" VALUES('comments',28);
INSERT INTO "sqlite_sequence" VALUES('payments',14);
INSERT INTO "sqlite_sequence" VALUES('portfolio',9);
INSERT INTO "sqlite_sequence" VALUES('reviews',4);
INSERT INTO "sqlite_sequence" VALUES('feedback',4);
COMMIT;